const EXIGIR_LOGIN = false;

const QUANTIDADE_ULTIMOS = 3; // quantos lançamentos aparecem na lista

// Cores da rosca, na ordem das categorias (da maior para a menor)
const CORES_CATEGORIAS = ["#0F3D2E", "#2E7D5B", "#A7D7B8", "#d9a441", "#7fa6c9"];

// Ícone (Font Awesome) de cada categoria. Se não achar, usa um padrão.
const ICONES_CATEGORIAS = {
  "moradia": "fa-house",
  "alimentação": "fa-utensils",
  "mercado": "fa-cart-shopping",
  "transporte": "fa-car",
  "lazer": "fa-dumbbell",
  "saúde": "fa-heart-pulse",
  "educação": "fa-graduation-cap",
  "trabalho": "fa-briefcase"
};


/* ---------- FUNÇÕES AUXILIARES ---------- */

// 4200 -> "R$ 4.200,00"
function formatarMoeda(valor) {
  return Number(valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

// Data de hoje como texto "2026-12-04" (mesmo formato salvo nos lançamentos)
function dataEmTexto(data) {
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const dia = String(data.getDate()).padStart(2, "0");
  return data.getFullYear() + "-" + mes + "-" + dia;
}

// "2026-12-04" -> "Hoje", "Ontem" ou "04/12"
function rotuloDaData(dataTexto) {
  const hoje = new Date();
  const ontem = new Date();
  ontem.setDate(hoje.getDate() - 1);

  if (dataTexto === dataEmTexto(hoje)) return "Hoje";
  if (dataTexto === dataEmTexto(ontem)) return "Ontem";

  const partes = dataTexto.split("-"); // ["2026", "12", "04"]
  return partes[2] + "/" + partes[1];
}


/* ---------- 1. USUÁRIO ---------- */
function mostrarUsuario() {
  const usuario = lerObjeto(CHAVE_USUARIO);
  const campoNome = document.getElementById("nome-usuario");

  // Ninguém logado
  if (!usuario || !usuario.nome) {
    if (EXIGIR_LOGIN) {
      window.location.href = "login.html";
      return;
    }
    campoNome.textContent = "visitante";
    return;
  }

  // Mostra só o primeiro nome: "Maria Silva" -> "Maria"
  // (textContent é mais seguro que innerHTML: o texto nunca vira código HTML)
  campoNome.textContent = usuario.nome.split(" ")[0];
}


/* ---------- 2. RESUMO (receitas, despesas e saldo do mês) ---------- */
function mostrarResumo(lancamentosDoMes) {
  let receitas = 0;
  let despesas = 0;

  lancamentosDoMes.forEach(function (lancamento) {
    if (lancamento.tipo === "receita") {
      receitas += Number(lancamento.valor);
    } else if (lancamento.tipo === "despesa") {
      despesas += Number(lancamento.valor);
    }
  });

  document.getElementById("total-receitas").textContent = formatarMoeda(receitas);
  document.getElementById("total-despesas").textContent = formatarMoeda(despesas);
  document.getElementById("saldo-atual").textContent = formatarMoeda(receitas - despesas);
}


/* ---------- 3. ROSCA: DESPESAS POR CATEGORIA ---------- */
function mostrarCategorias(lancamentosDoMes) {
  const rosca = document.getElementById("grafico-categorias");
  const legenda = document.getElementById("legenda-categorias");
  legenda.innerHTML = ""; // limpa a legenda antiga

  // a) Soma as despesas de cada categoria: { "Moradia": 1000, "Lazer": 200 }
  const totais = {};
  let totalGeral = 0;

  lancamentosDoMes.forEach(function (lancamento) {
    if (lancamento.tipo !== "despesa") return;
    const categoria = lancamento.categoria || "Outros";
    totais[categoria] = (totais[categoria] || 0) + Number(lancamento.valor);
    totalGeral += Number(lancamento.valor);
  });

  rosca.setAttribute("data-total", formatarMoeda(totalGeral)); // texto do centro

  // Sem despesas: rosca cinza e aviso na legenda
  if (totalGeral === 0) {
    rosca.style.background = "#e3e9e4";
    adicionarNaLegenda(legenda, "Sem despesas este mês", "", "#e3e9e4");
    return;
  }

  // b) Ordena da maior para a menor. Mostra as 4 maiores e junta o resto em "Outros"
  let itens = Object.keys(totais)
    .map(function (nome) { return { nome: nome, valor: totais[nome] }; })
    .sort(function (a, b) { return b.valor - a.valor; });

  if (itens.length > 5) {
    const resto = itens.slice(4).reduce(function (soma, item) { return soma + item.valor; }, 0);
    itens = itens.slice(0, 4).concat({ nome: "Outros", valor: resto });
  }

  // c) Monta o degradê em pizza e a legenda, uma fatia por categoria
  let inicio = 0;
  const fatias = [];

  itens.forEach(function (item, indice) {
    const cor = CORES_CATEGORIAS[indice];
    const fim = inicio + (item.valor / totalGeral) * 100;
    fatias.push(cor + " " + inicio + "% " + fim + "%"); // ex.: "#0F3D2E 0% 35%"
    inicio = fim;

    const porcentagem = Math.round((item.valor / totalGeral) * 100);
    adicionarNaLegenda(legenda, item.nome, porcentagem + "%", cor);
  });

  rosca.style.background = "conic-gradient(" + fatias.join(", ") + ")";
}

// Cria uma linha da legenda: <li style="--cor:..">Nome <b>35%</b></li>
function adicionarNaLegenda(legenda, nome, porcentagem, cor) {
  const li = document.createElement("li");
  li.style.setProperty("--cor", cor);
  li.textContent = nome + " ";

  if (porcentagem) {
    const negrito = document.createElement("b");
    negrito.textContent = porcentagem;
    li.appendChild(negrito);
  }
  legenda.appendChild(li);
}


/* ---------- 4. ÚLTIMOS LANÇAMENTOS ---------- */
function mostrarUltimosLancamentos(todosLancamentos) {
  const lista = document.getElementById("ultimos-lancamentos");
  lista.innerHTML = ""; // apaga os exemplos

  if (todosLancamentos.length === 0) {
    const aviso = document.createElement("li");
    aviso.className = "vazio";
    aviso.textContent = "Nenhum lançamento cadastrado ainda.";
    lista.appendChild(aviso);
    return;
  }

  // Mais recentes primeiro (data maior = mais recente) e pega só os primeiros
  const maisRecentes = todosLancamentos
    .slice() // copia a lista para não bagunçar a original
    .sort(function (a, b) {
      return b.data.localeCompare(a.data) || ((b.id || 0) - (a.id || 0));
    })
    .slice(0, QUANTIDADE_ULTIMOS);

  maisRecentes.forEach(function (lancamento) {
    lista.appendChild(criarItemLancamento(lancamento));
  });
}

// Monta o <li> de um lançamento usando createElement
function criarItemLancamento(lancamento) {
  const categoria = (lancamento.categoria || "").toLowerCase();
  const ehReceita = lancamento.tipo === "receita";

  // Cor da caixinha: lazer = roxo; senão receita = verde, despesa = rosa
  const corCaixa = categoria === "lazer" ? "lazer" : (ehReceita ? "receita" : "despesa");
  const nomeIcone = ICONES_CATEGORIAS[categoria] || (ehReceita ? "fa-wallet" : "fa-receipt");

  const li = document.createElement("li");

  // Lado esquerdo: ícone + nome + data
  const esquerda = document.createElement("div");
  esquerda.className = "lancamento";

  const caixa = document.createElement("span");
  caixa.className = "icone-caixa " + corCaixa;
  const icone = document.createElement("i");
  icone.className = "fa-solid " + nomeIcone;
  caixa.appendChild(icone);

  const textos = document.createElement("div");
  const nome = document.createElement("span");
  nome.className = "nome";
  nome.textContent = lancamento.descricao;
  const data = document.createElement("small");
  data.textContent = rotuloDaData(lancamento.data);
  textos.appendChild(nome);
  textos.appendChild(data);

  esquerda.appendChild(caixa);
  esquerda.appendChild(textos);

  // Lado direito: valor com sinal e cor
  const valor = document.createElement("span");
  valor.className = ehReceita ? "valor-receita" : "valor-despesa";
  valor.textContent = (ehReceita ? "+ " : "- ") + formatarMoeda(lancamento.valor);

  li.appendChild(esquerda);
  li.appendChild(valor);
  return li;
}


/* ---------- 5. BOTÃO SAIR ---------- */
function configurarSair() {
  const botaoSair = document.querySelector(".sair");
  if (botaoSair) {
    // Ao clicar, apaga o usuário logado. O link leva para o login.html.
    botaoSair.addEventListener("click", function () {
      apagarDado(CHAVE_USUARIO);
    });
  }
}


/* ---------- JUNTAR TUDO ---------- */
function iniciarDashboard() {
  const todos = lerLista(CHAVE_LANCAMENTOS);

  // Só os lançamentos do mês atual: a data começa com "2026-12"
  const mesAtual = dataEmTexto(new Date()).slice(0, 7);
  const doMes = todos.filter(function (lancamento) {
    return typeof lancamento.data === "string" && lancamento.data.slice(0, 7) === mesAtual;
  });

  mostrarUsuario();
  mostrarResumo(doMes);
  mostrarCategorias(doMes);
  mostrarUltimosLancamentos(todos);
  configurarSair();
}

// O script fica no fim do <body>, então o HTML já existe quando isto roda
iniciarDashboard();
