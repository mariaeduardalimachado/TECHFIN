
const CHAVE_USUARIO = "usuarioLogado";   // Duda grava: { nome, email }
const CHAVE_LANCAMENTOS = "lancamentos"; // Erick grava: lista de receitas e despesas

// Lê uma LISTA salva (ex.: lançamentos). Se não houver nada, devolve [].
function lerLista(chave) {
  try {
    const lista = JSON.parse(localStorage.getItem(chave));
    return Array.isArray(lista) ? lista : [];
  } catch (erro) {
    return []; // texto quebrado no localStorage: devolve lista vazia
  }
}

// Lê UM objeto salvo (ex.: o usuário logado). Se não houver, devolve null.
function lerObjeto(chave) {
  try {
    return JSON.parse(localStorage.getItem(chave));
  } catch (erro) {
    return null;
  }
}

// Salva qualquer lista ou objeto (converte para texto com JSON.stringify)
function salvarDado(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}

// Apaga uma gaveta (usado no "Sair")
function apagarDado(chave) {
  localStorage.removeItem(chave);
}
